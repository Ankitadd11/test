<?php

define("URL_CSV_FILE_NAME", 'Inputs/url-file.csv');
//define("WORD_SOURCE_FILE_NAME", 'Inputs/word-file.csv');
define("WORD_SOURCE_FILE_NAME", 'Inputs/word-file.csv');
define("NAME_SOURCE_FILE_NAME", 'Inputs/name-file.csv');

define("JSON_FILE_NAME", 'parserUrls.json');
define("LOG_FOLDER_PATH", 'Logs/');
define("OUT_FILE_FOLDER_PATH", 'OutputFiles/');


?>