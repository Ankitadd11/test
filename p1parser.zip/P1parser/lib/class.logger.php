<?php

/******************************************************************************	
	File Name   : class.logger.php
	Purpose     : To write the logs.
	Updated Date: 3 March 2018.
	Developer   : Ganesh Mulay. 
******************************************************************************/
class Logger
{

	public $filePath;

	function __construct(){
		$this->filePath = LOG_FOLDER_PATH.'log-'.date("d-m-Y").'.txt';
	}

	//create new blank file
	private function createLogFile(){
		$handle = fopen($this->filePath, 'w');
	}

	//create/Edit file and writes the logs.
	public function writeLogFile( $msg ){

		if( !file_exists( $this->filePath ) ){
			$this->createLogFile();
		}

		$file = fopen($this->filePath, 'a+');

		$logText = date("d-m-Y:h:i:sa")." - ".$msg;
		fwrite($file, $logText.PHP_EOL);
		fclose($file);
	}
}



?>