<?php
/******************************************************************************	
	File Name   : index.php
	Purpose     : To parse the urls using the approach 1 which is
			      Find the anchor tag (<a>) before the matching names and words.
	Updated Date: 7 March 2018.
	Developer   : Ganesh Mulay. 
******************************************************************************/



//purpose: To increase execution time
ini_set('max_execution_time', 600);
#==============================================================
include("constant.php"); //define Constant variableS
include("lib/simple_html_dom.php"); //All Core files are avalainble in this file e.gplaintext,outerstack
include("lib/class.logger.php"); // logger fuctions
include("process/commonFunction.php");//all common Functions.
include("process/process.php");//main process part of parser
#==============================================================
logs("==============================================================");
logs("parser p1 started ".date("Y-m-d H:i:s"));

echo "<pre>";

$allWords = csvFileToArray( "../".WORD_SOURCE_FILE_NAME );//To get words from words-source-file.
$allNames = csvFileToArray( "../".NAME_SOURCE_FILE_NAME );//To get name from names-source-file.

$allWords = UpdateArrayWithHyphen( $allWords );
$allNames = UpdateArrayWithHyphen( $allNames );


/*print_r( $allWords );
print_r( $allNames );
*/


logs("Read the json file and get URL list for this parser");

$urlList = getURLListForParser(JSON_FILE_NAME); //Get url list for parser from json //process.php
$headlineArray = array(); //initialize blank array for headlines

/*
$url = "http://www.handelsblatt.com/politik/deutschland/grosse-koalition-gabriel-muss-job-als-aussenminister-aufgeben-auch-hendricks-ist-raus/21047284.html";
$html = file_get_html( $url );

$a = $html->find('span[class=vhb-overline--onecolumn]');
foreach($a as $b) {

	foreach ($b as $c) {
		echo $c->outertext."<br>";
	}
} 

exit;
*/
/*New Urls send to parser*/
try {
	//throw an exception when $urlList is not an array.
	if( !is_object($urlList)){
		throw new Exception("Url list should be array/object");
	}
	
		foreach ( $urlList as $url ) {

			$temp = "";
			logs("Start Parsing for the URL:".$url);
			logs("Form the headline URLs for the matching words and names");
			$headlineArray = processNameList($allNames, $url, $temp, $headlineArray); // find names in html-content of given url
			$headlineArray = processWordList($allWords, $url, $temp, $headlineArray); // find Words in html-content of given url
		}//end of UrlList	

		

		$headlineArray = array_unique($headlineArray); //remove duplicate URLs.
		print_r( $headlineArray );

		logs("For each headline check matching words, names and create output file");

		processHeadlineUrls($headlineArray, $allWords, $allNames); //count the number of words from string and generate output file

		logs("Parsing for the URL Completed");
		
} catch (Exception $e) {
	logs("Urls not parse and its throw an error: ".$e->getMessage());
	echo 'Message: ' .$e->getMessage();
	
}

logs("==============================================================");



?>