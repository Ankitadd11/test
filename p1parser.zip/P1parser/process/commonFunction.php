<?php
//function to read csv and it will return array.
function csvFileToArray($fileName){
	//open file
	$file = fopen($fileName,"r");
	$parserArray = array();
	//read csv file and push each url data in array
	while (($data = fgetcsv($file, '')) !== FALSE) {
		return $data;
		//array_push($parserArray, strtolower( $data) );
	}
	//return $parserArray;
}

function UpdateArrayWithHyphen( $WordNameArray ){
	$finalArray = array();
	foreach( $WordNameArray as $wordName ){
		array_push($finalArray , $wordName);
		if (strpos( trim($wordName), ' ') !== false) {
		    array_push($finalArray , str_replace(' ', '-', $wordName));
		}
		
	}
	return $finalArray;
}

//check url is presnt or not in json and if present return array of new urls.
function checkUrlPresentOrNot($jsonUrl, $urlData){
	$json = file_get_contents($jsonUrl);
	$jsonUrls = json_decode( $json );
	$temp = 1;
	$newUrlArray = array();

	//print_r( $urlData );

	//first loop for file urls.
	foreach( $urlData as $fileUrl ){
		//print_r( $fileUrl );
		//foreach( $fileUrl as $finalUrl ){
			//second loop for json parsers
			foreach( $jsonUrls as $jUrl ){
				//third loop for urls of parsers
				foreach( $jUrl as $key => $url ){
					if( in_array($fileUrl, (array)$url) ){
						$temp++;
						continue 2;
					}else{
						$temp = 1;
					}
				}
			}
			//if urls is not present in json then urls pushing into array.
			if( $temp == 1 ){
				array_push($newUrlArray, $fileUrl);
			}
		//}
		
	}

	//sendNewUrlToEachParser($newParserArray);
	return $newUrlArray;
}

function executeNewUrlByEachParser($newUrlsToParse,$parsers){
	$parser_key = "";
	$parser = "";
	$newUrl = "";
	UpdateJsonFile($parser_key, $parser, $newUrl);
	
	/*foreach( $newUrlsToParse as $newUrl ){
		foreach( $parsers as $key => $parser ){
			if( $parser($newUrl) ){
				UpdateJsonFile($parser_key, $parser, $newUrl);
				continue 1;
			}
		}
	}*/
}

function UpdateJsonFile($parser_key, $parser, $newUrl){
	
	$jsonString = file_get_contents( JSON_FILE_NAME );
	$data = json_decode($jsonString, true);
	
	$cnt = count( $data['Parsers'][$parser] ) + 1;
	$data['Parsers'][$parser][$parser_key.'_'.$cnt] = $newUrl;

	$jsonString = json_encode($data);
	file_put_contents(JSON_FILE_NAME, $jsonString);
}

//get url list for a specific parser
function getUrlListForAParser($jsonUrl, $parserName){
	$json = file_get_contents($jsonUrl);
	$jsonUrls = json_decode( $json );
	$parserArray = array();
	foreach( $jsonUrls as $jUrl ){
		foreach( $jUrl as $key => $url ){
			if( $key == $parserName ){
				array_push($parserArray, $url);
			}
		}
	}
	return $parserArray;
}

function countWordsFromString($string, $wordsArray, $namesArray, $url){
	
	$urlAndWordCountArray = array();
	$resultWordArray = array();
	$resultNameArray = array();
	
		foreach( $wordsArray as $word ){
			$finalWord = strtolower( utf8_encode($word) );
			
			if( $finalWord !== '' && (substr_count($string, $finalWord) > 0)){
				array_push($resultWordArray, $finalWord);
				//$countArray[$word] = substr_count($string, $word);
			}
		}

		foreach( $namesArray as $Name ){
			$finalName = strtolower( utf8_encode($Name) );
			if( $finalName !== '' && (substr_count($string, $finalName)>0)){
				array_push($resultNameArray, $finalName);
				//$ = substr_count($string, $word);
			}
		}

		//$countArray['url'] = $url;
		$urlAndWordCountArray['url'] = $url;
		$urlAndWordCountArray['matchedWords'] = $resultWordArray;
		$urlAndWordCountArray['matchedNames'] = $resultNameArray;
	

	return $urlAndWordCountArray;
}

function sendMail($url){

	require 'PHPMailer/src/Exception.php';
	require 'PHPMailer/src/PHPMailer.php';
	require 'PHPMailer/src/SMTP.php';

	$mail = new PHPMailer\PHPMailer\PHPMailer(true);

	try {
	    $mail->SMTPDebug = 2;
	    $mail->isSMTP();
	    $mail->Host = 'smtp.gmail.com.';
	    $mail->SMTPAuth = true;
	    $mail->Username = '';
	    $mail->Password = '';
	    $mail->SMTPSecure = 'tls';
	    $mail->Port = 587;

	    //Recipients
	    $mail->setFrom('', '');
	    $mail->addAddress('', '');
	    
	    //Content
	    $mail->isHTML(true);
	    $mail->Subject = 'Not getting parsed successfully';
	    $mail->Body    = 'Today parser observed new url which is not getting parsed successfully by any existing parsers.URL Details{URL: $url}Date & time ';

	    $mail->send();
	    echo 'Message has been sent';
	} catch (Exception $e) {
	    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
	}
}

function logs($msg){
	$objLog = new Logger;
	$objLog->writeLogFile($msg);
}

function hasDomain($url){
	$UrlArr = parse_url($url);
	if( array_key_exists('host', $UrlArr) ){
		return true;
	}else{
		return false;
	}
	
}

function findTagsFromHTMLContent($childNode, $temp, $word, $url, $headlineArray){
	
	$doNotFind = array('noscript','script','img','input','style','title');
	foreach( $childNode->children() as $child){
		$tempUrl = '';
		if( $child->tag == 'a' ){
			$temp = $tempUrl = $child->href;
		}

		if(stripos($child->plaintext, $word) !== false){
			if( $tempUrl != '' ){
				if( !hasDomain($temp) ){
					$UrlArr = parse_url($url);
					$temp = $UrlArr['scheme']."://".$UrlArr['host'].$temp;
				}

				array_push($headlineArray, $temp);
			}

			$headlineArray = findTagsFromHTMLContent($child, $tempUrl, $word, $url, $headlineArray);
		}
	}

	return $headlineArray;

	
}


?>