<?php
/******************************************************************************	
	File Name   : class.logger.php
	Purpose     : To write the logs.
	Updated Date: 3 March 2018.
	Developer   : Ganesh Mulay. 
******************************************************************************/
//get url list for a parser from json
function getURLListForParser($jsonUrl){
	$json = file_get_contents( "../".$jsonUrl );
	$jsonUrls = json_decode( $json );
	return $jsonUrls->Parsers->parser1;
}

// find names in html-content of url.
function processNameList($allNames, $url, $temp, $headlineArray){
	$html = file_get_html( $url );
	$finalName = '';
	foreach( $allNames as $name ){
		$finalName = htmlentities( strtolower($name), ENT_IGNORE , "ISO-8859-1");
		if (stripos( strtolower($html->outertext), $finalName) !== false) {
			
		    foreach($html->find('body') as $element) {

		    	foreach( $element->children() as $child){
		    		$headlineArray = findTagsFromHTMLContent($child, $temp, $finalName, $url, $headlineArray);
			    }
			} 
		}
	}

	return $headlineArray;
}

// find Words in html-content of url.
function processWordList($allWords, $url, $temp, $headlineArray){
	$html = file_get_html( $url );

	$finalWord = '';
	foreach( $allWords as $word ){

   		$finalWord = htmlentities( strtolower($word), ENT_IGNORE , "ISO-8859-1");
   		
		if (stripos(strtolower( $html->outertext ), $finalWord)  !== false) {

			foreach($html->find('body') as $element) {

		    	foreach( $element->children() as $child){
		    		$headlineArray = findTagsFromHTMLContent($child, $temp, $finalWord, $url, $headlineArray);
			    }
			} 
		}
	}

	return $headlineArray;
}

//To count number of words from string and generate outputfile.
function processHeadlineUrls($headlineArray, $allWords, $allNames){
	foreach( $headlineArray as $headline ){
		$html = file_get_html($headline);
		$htmlContent = "";
		$json = file_get_contents( 'step2ContentJson.json' );
		$jsonUrls = json_decode( $json );		
		$UrlArr = parse_url($headline);
		$headlineDomain = $UrlArr['host'];
        
        if( isset($jsonUrls->step2Urls->$headlineDomain) ){
        	$htmlTag = $jsonUrls->step2Urls->$headlineDomain;
        	foreach( explode('|', $htmlTag) as $tag ){
        		if( count( $html->find($tag) ) > 0){
	        		foreach($html->find($tag) as $element) {
						$htmlContent .= $element->plaintext;
					}
				}
        	}
        }else{
        	foreach($html->find('article') as $element) {
				$htmlContent .= $element->plaintext;
			}
			//echo $htmlContent."<br>";
        }
		
		if( $htmlContent != '' ){
			$outputResultArray = countWordsFromString( strtolower( $htmlContent ), $allWords, $allNames, $headline);
			print_r( $outputResultArray );
			//generateOutputFile($outputResultArray);
		}
		
	}
}

//generate outputfile from result array as per given format
function generateOutputFile($outputResultArray){


	    
	    $url="";
	    $firstName="";
	    $wordCount=0;
        $outputFileName="";

		$url=$outputResultArray['url'];
		if(count($outputResultArray['matchedNames'])>0){
			$firstName=$outputResultArray['matchedNames'][0];
		}else{
			$firstName="WORDS";
		}
		$wordCount=count($outputResultArray['matchedWords']);
		//create File Name
		$outputFileName = $firstName."_".$wordCount."_".time()."&".date("Y-m-d");
		//create CSV output file
		$file = fopen( "../".OUT_FILE_FOLDER_PATH.$outputFileName.".csv","w");

		$nameArray = array_map("utf8_decode", $outputResultArray['matchedNames']);
		$wordArray = array_map("utf8_decode", $outputResultArray['matchedWords']);
		//print_r( $outputResultArray['matchedWords'] );
		/*print_r( $nameArray );
		print_r( $wordArray );*/
		fputcsv($file, $nameArray);
		fputcsv($file, $wordArray);
		fputcsv($file, array($url));
		fclose($file);	


}	

?>